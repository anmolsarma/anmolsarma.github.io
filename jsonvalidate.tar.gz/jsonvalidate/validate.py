from __future__ import print_function

import json
import sys

import jsonschema

file_path = sys.argv[1]

rt_schema = None
nna_schema = None
ftt_schema = None

with open(file_path) as f:
    for line in f:
        tag, value = line.split('=')
        payload = json.loads(value.replace('//,', ','))
        type = tag.split('.')[1]
        if type == 'RT':
            schema = rt_schema
        elif type == 'NNA':
            schema = nna_schema
        elif type == 'FTT':
            schema = ftt_schema
        else:
            print('ERROR: Unknown type %s for %s' % (type, tag))

        try:
            jsonschema.validate(payload, schema)
            print('%s is valid')
        except jsonschema.ValidationError as e:
            print('ERROR: Validation of %s failed:' % tag)
            print(e.message)
