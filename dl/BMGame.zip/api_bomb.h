#ifndef __API_BOMB_H__
#define __API_BOMB_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __MINGW__
#define DLL_EXPORT 
#else //_MSC_VER
#define DLL_EXPORT __declspec(dllexport) 
#endif

typedef struct GameApi_
{
	// Function: Obtain which side my side is
	// Return value: PLAYER_L indicates that I am the left side / PLAYER_R indicates that I am the right side.
	int (*api_whoami)();
	
	// Function: Obtains the status of the grid which is in the column "col" and the row "row".
	// Parameter Description: row Range [0, api_getMatrixRow()-1], col Range [0, api_getMatrixCol()-1]
	// Return value: GRID_EMPTY/GRID_LEFT/GRID_RIGHT/GRID_FENCE/GRID_BOMB1/GRID_BOMB2. If the input parameter is invalid, the return value is not defined.
    int (*api_getGridInfo)(int row, int col);

	// Function: Send the action to the server and specify the small person of my side to walk.
	// Parameter Description: iRow/iCol: Specify the location of small person of my side(row/column)
	//						direction: Specify the moving direction of small person of my side DIR_UP/DIR_DOWN/DIR_LEFT/DIR_RIGHT
	// 						leave_bomb: Specify whether to place a bomb at the position where the small person just left.
	// 									0: No
	// 									N(N>1): Place a bomb. And the bomb will explode after N rounds. If N is invalid, the bomb will be placed unsuccessfully .
	// 									Note: This parameter is not the value of GRID_BOMB1/GRID_BOMB2. Please set 1 or 2 (The value 3 and above are not supported currently)
	// Remarks:Only one api_walk instruction can be sent in one round. If multiple api_walk instructions are sent, sever will just execute the first one.
    void (*api_walk)(int row, int col, int direction, int leave_bomb);

	// Function: Printing logs (The server will add the log header automatically). If any new line is required, please input the line feed character in the str parameter.
    void (*api_log)(const char* fmt, ...);

	// Function: Printing logs (The server will not add the log header). If any new line is required, please input the line feed character in the str parameter.
    void (*api_log_without_logheader)(const char* fmt, ...);

	//==============================================================
	// The following is the total score calculation function.
	// Total score = Number of survival small persons * 1000 * 1000 + Number of dropped bombs * 1000 + Number of steps
	// When the number of survival small persons of both side in the game are greater than 0, it will compare the total score of two side. The side whose total score is more will win.
	// We can use the api_getSelfScore() > api_getOppoScore() method to determine whether the current side is in the dominant state.
	//==============================================================
    
	// Function:To obtain the total score of my side before the current round. The total score excludes the score of the action in the current round.
	// Return value: Total score
    int (*api_getSelfScore)();

	// Function: To obtain the total score of opposite side before the current round. The total score excludes the score of the action in the current round.
	// Return value: Total score
    int (*api_getOppoScore)();
}GameApi ;

// The entry function which shall be coded by participants.
DLL_EXPORT void play(GameApi* func);

// Constant Definition

#ifdef __CLIENT_USE__

#define CLI_MAX_ROW  10
#define CLI_MAX_COL  10

#define CLI_GRID_EMPTY 0 //Blank
#define CLI_GRID_LEFT  101 //The small person of left side
#define CLI_GRID_RIGHT 102 //The small person of right side

#define CLI_GRID_BOMB1 201 //Bomb: Explode after the play () of this round
#define CLI_GRID_BOMB2 202 //Bomb: It will not explode after the play () of this round. But it will explode after the play () of the next round.

#define CLI_GRID_FENCE 300 //Fence(obstacle)

#define CLI_PLAYER_L CLI_GRID_LEFT   //Left Side
#define CLI_PLAYER_R CLI_GRID_RIGHT  //Right Side

#define CLI_DIR_UP     0  //Upward
#define CLI_DIR_DOWN   1  //Downward
#define CLI_DIR_LEFT   2  //Left
#define CLI_DIR_RIGHT  3  //Right

#endif

#ifdef __cplusplus
}
#endif

#endif /* __API_BOMB_H__ */

